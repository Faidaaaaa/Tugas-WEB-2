<?php
$url = 'https://data.jakarta.go.id/read-resource/json/data-penyedia-jasa-angkutan-sampah-di-provinsi-dki-jakarta-tahun-2019/a019b8ab-9761-4161-9280-ae251ce9eef4';
$json = file_get_contents($url);
$data = json_decode($json,true);

?>

<table border="1">
    <tr>
        <td>Nama Perusahaan</td>
        <td>Alamat Perusahaan</td>
        <td>Koordinat Lintang Selatan</td>
        <td>Koordinat Bujur Selatan</td>
    </tr>

    <?php
    
    for($i=0; $i<count($data);$i++){
        $row=$data[$i];
        ?>

        <tr>
            <td><?php echo $row['nama_perusahaan'] ?></td>
            <td><?php echo $row['alamat_perusahaan'] ?></td>
            <td><?php echo $row['lintang_selatan'] ?></td>
            <td><?php echo $row['bujur_selatan'] ?></td>

        </tr>
    <?php
    }
    
    ?>

</table>